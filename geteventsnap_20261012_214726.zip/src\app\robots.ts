import type { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: '*',
      allow: '/',
      disallow: ['/dashboard/', '/admin/', '/giris', '/kayit', '/sifre-yenile', '/api/'],
    },
    sitemap: 'https://www.geteventsnap.com/sitemap.xml',
  }
}
