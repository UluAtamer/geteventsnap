export function getPublicAppUrl(path: string, requestUrl: URL) {
  return new URL(path, process.env.NEXT_PUBLIC_SITE_URL || requestUrl.origin)
}
