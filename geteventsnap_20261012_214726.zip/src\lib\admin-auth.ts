import 'server-only'

import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'

export async function requireAdmin() {
  const adminEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase()
  if (!adminEmail) {
    throw new Error('ADMIN_EMAIL sunucu ortam değişkeni yapılandırılmamış.')
  }

  const supabase = await createClient()
  const { data: { user }, error } = await supabase.auth.getUser()

  if (error || !user) {
    redirect('/giris')
  }

  if (user.email?.toLowerCase() !== adminEmail) {
    redirect('/dashboard')
  }

  return user
}
